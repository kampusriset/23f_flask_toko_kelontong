Sistem Kasir - Toko Mandiri Jaya
================================

Langkah cepat menjalankan (Windows):
1. Ekstrak folder `toko_mandiri_jaya`.
2. Buka Command Prompt:
